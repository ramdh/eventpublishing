This application provides a registration form for a workshop. Registrations are stored in a Cloudant database on IBM Cloud Platform.

Deployment instructions are in file events-app-navodila.pdf.

Database

- is defined in app.js
- database name is defined in variable dbName. You must change this name to something else that will fit your need. Add the date into the name, example: name-09272018
# eventpublishing
